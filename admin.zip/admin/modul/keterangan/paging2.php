<?php 
$koneksi = mysqli_connect('localhost', 'root', '', 'absenkaryawan');

    $batas = 5;
$halaman = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$halaman_awal = ($halaman>1) ? ($halaman * $batas) - $batas : 0;

$previous = $halaman - 1;
$next = $halaman + 1;

$id_author = $_SESSION['idabsen2'];
$data = mysqli_query($koneksi, "SELECT * FROM tb_kegiatan WHERE id_author = '$id_author' ");
$jumlah_data = mysqli_num_rows($data);
$total_halaman = ceil($jumlah_data / $batas);

$data = mysqli_query($koneksi, "SELECT * FROM tb_karyawan");

$nomor = $halaman_awal+1;

if (isset($_POST['lihat'])) {
    lihat_laporan();
}

// cari
if (isset($_POST['go'])) {
  $cari = $_POST['cari'];
  $karyawan = mysqli_query($koneksi, "SELECT * FROM tb_kegiatan WHERE id_author LIKE '%".$cari."%'");
}else{
  $karyawan = mysqli_query($koneksi, "SELECT * FROM tb_kegiatan LIMIT $halaman_awal, $batas");
}


foreach (lihat_laporan() as $row):
    ?>
      
  
  
  
  <tr>
                                <td><?= $i++;  ?></td>
                                <td><?=  $pro['kategori'];?></td>
                                <td><?=  $pro['deskripsi'];?></td>
                                <td><?= $pro['tgl_mulai'];?></td>
                                <td><?=  $pro['waktu_mulai'];?></td>
                                <td><?= $pro['tgl_selesai'];?></td>
                                <td><?=  $pro['waktu_selesai'];?></td>
                                <td><?= $pro['email'];?></td>
                              
  
  
  
  
                                </tr> 
                                <?php endforeach; ?>
    



